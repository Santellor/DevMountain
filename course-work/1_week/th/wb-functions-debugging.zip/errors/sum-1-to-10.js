// Sum numbers from 1 to 10.
let n = 1;
let sum = 0;

while (n > 10) {
  sum += n;
  n += 1;
}

console.log("The sum of the numbers from 1-10 is", sum)
