function giveMeSomething(a) {
  return "something " + a;

giveMeSomething("does this work?");