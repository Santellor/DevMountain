const fruits = ['apple', 'berry', 'cherry'];

const upperFruit = fruits[10].toUpperCase();

console.log(upperFruit);
