const fruits = ['apple', 'berry', 'cherry'];
if fruits[0] === 'apple' {
  console.log('Apple is the first fruit');
}
