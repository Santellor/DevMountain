const outputScore = (score) => {
  console.log(`You win! Your score is ${score}`);
};

const score = 10;
outputScore(score);
