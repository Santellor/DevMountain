module.exports = {
  testResultsProcessor: './node_modules/jest-html-reporter',
};
