export default function LoginPage() {
  return (
    <>
      <h1>Log In</h1>
      <p>TODO</p>
    </>
  );
}
