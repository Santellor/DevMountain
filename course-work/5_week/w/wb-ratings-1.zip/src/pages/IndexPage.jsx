export default function IndexPage() {
  return (
    <>
      <h1>Movie Ratings App</h1>
      <p>Welcome!</p>
    </>
  );
}
