export default function YourRatingsPage() {
  return (
    <>
      <h1>Your Ratings</h1>
      <p>TODO</p>
    </>
  );
}
